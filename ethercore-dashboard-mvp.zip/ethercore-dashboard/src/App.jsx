import { useCallback, useEffect, useMemo, useState } from "react";
import { BrowserProvider, Contract, formatUnits } from "ethers";
import {
  Activity, ArrowDownLeft, ArrowUpRight, Bell, Check, ChevronDown,
  CircleHelp, Copy, ExternalLink, FileCode2, Globe2, LayoutDashboard,
  LockKeyhole, Menu, RefreshCw, ShieldCheck, Wallet, X, Zap
} from "lucide-react";

const TOKEN_ABI = [
  "function name() view returns (string)",
  "function symbol() view returns (string)",
  "function decimals() view returns (uint8)",
  "function totalSupply() view returns (uint256)",
  "function balanceOf(address) view returns (uint256)"
];

const CONTRACT_ADDRESS = import.meta.env.VITE_CONTRACT_ADDRESS || "";
const TARGET_CHAIN_ID = Number(import.meta.env.VITE_CHAIN_ID || 11155111);
const CHAIN_NAME = import.meta.env.VITE_CHAIN_NAME || "Sepolia";
const EXPLORER_URL = import.meta.env.VITE_EXPLORER_URL || "https://sepolia.etherscan.io";
const SHORT_ADDRESS = (value) => value ? `${value.slice(0, 6)}...${value.slice(-4)}` : "Not configured";

function App() {
  const [account, setAccount] = useState("");
  const [chainId, setChainId] = useState(null);
  const [balance, setBalance] = useState(null);
  const [tokenName, setTokenName] = useState("CoreToken");
  const [symbol, setSymbol] = useState("CT");
  const [decimals, setDecimals] = useState(18);
  const [supply, setSupply] = useState(null);
  const [status, setStatus] = useState("idle");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [copied, setCopied] = useState(false);
  const [mobileMenu, setMobileMenu] = useState(false);

  const networkMatches = chainId === TARGET_CHAIN_ID;
  const configured = Boolean(CONTRACT_ADDRESS);

  const connectWallet = useCallback(async () => {
    setError("");
    if (!window.ethereum) {
      setError("No browser wallet detected. Install MetaMask or open this site in a wallet-enabled browser.");
      return;
    }
    try {
      setBusy(true);
      const provider = new BrowserProvider(window.ethereum);
      await provider.send("eth_requestAccounts", []);
      const signer = await provider.getSigner();
      const network = await provider.getNetwork();
      setAccount(await signer.getAddress());
      setChainId(Number(network.chainId));
      setStatus("connected");
    } catch (e) {
      setError(e?.shortMessage || e?.message || "Wallet connection was cancelled.");
    } finally {
      setBusy(false);
    }
  }, []);

  const refreshData = useCallback(async () => {
    if (!window.ethereum || !account || !configured) return;
    try {
      setStatus("loading");
      const provider = new BrowserProvider(window.ethereum);
      const network = await provider.getNetwork();
      const currentChain = Number(network.chainId);
      setChainId(currentChain);
      if (currentChain !== TARGET_CHAIN_ID) {
        setBalance(null);
        setSupply(null);
        setStatus("wrong-network");
        return;
      }
      const token = new Contract(CONTRACT_ADDRESS, TOKEN_ABI, provider);
      const [name, ticker, places, total, walletBalance] = await Promise.all([
        token.name(), token.symbol(), token.decimals(), token.totalSupply(),
        token.balanceOf(account)
      ]);
      setTokenName(name);
      setSymbol(ticker);
      setDecimals(Number(places));
      setSupply(formatUnits(total, Number(places)));
      setBalance(formatUnits(walletBalance, Number(places)));
      setStatus("connected");
      setError("");
    } catch (e) {
      setStatus("error");
      setError(e?.shortMessage || e?.message || "Unable to read the token contract. Check the network and contract address.");
    }
  }, [account, configured]);

  useEffect(() => {
    if (window.ethereum?.on) {
      const onAccounts = (accounts) => {
        setAccount(accounts?.[0] || "");
        if (!accounts?.length) { setBalance(null); setStatus("idle"); }
      };
      const onChain = (hex) => {
        setChainId(Number(hex));
        setBalance(null);
        setSupply(null);
      };
      window.ethereum.on("accountsChanged", onAccounts);
      window.ethereum.on("chainChanged", onChain);
      return () => {
        window.ethereum.removeListener?.("accountsChanged", onAccounts);
        window.ethereum.removeListener?.("chainChanged", onChain);
      };
    }
  }, []);

  useEffect(() => {
    if (account && configured) refreshData();
  }, [account, configured, refreshData]);

  const copyAddress = async () => {
    if (!CONTRACT_ADDRESS) return;
    await navigator.clipboard.writeText(CONTRACT_ADDRESS);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1500);
  };

  const formattedBalance = useMemo(() => {
    if (balance === null) return "—";
    const n = Number(balance);
    return Number.isFinite(n) ? n.toLocaleString(undefined, { maximumFractionDigits: 4 }) : balance;
  }, [balance]);

  const formattedSupply = useMemo(() => {
    if (supply === null) return "100,000,000";
    const n = Number(supply);
    return Number.isFinite(n) ? n.toLocaleString(undefined, { maximumFractionDigits: 0 }) : supply;
  }, [supply]);

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileMenu ? "sidebar-open" : ""}`}>
        <div className="brand">
          <div className="brand-mark"><span> E </span></div>
          <div><strong>ETHERCORE</strong><small>WEB3 ECOSYSTEM</small></div>
          <button className="icon-btn mobile-close" onClick={() => setMobileMenu(false)} aria-label="Close menu"><X size={18}/></button>
        </div>
        <div className="nav-caption">WORKSPACE</div>
        <nav>
          <a className="nav-link active" href="#overview"><LayoutDashboard size={18}/> Overview</a>
          <a className="nav-link" href="#token"><Zap size={18}/> CoreToken</a>
          <a className="nav-link" href="#contract"><FileCode2 size={18}/> Contract</a>
        </nav>
        <div className="sidebar-bottom">
          <div className="secure-card">
            <div className="secure-icon"><ShieldCheck size={18}/></div>
            <strong>Self-custody first</strong>
            <p>Your wallet stays yours. EtherCore never asks for your seed phrase or private key.</p>
          </div>
          <div className="sidebar-foot"><span className="live-dot"/> Interface preview <span className="version">v1.0</span></div>
        </div>
      </aside>

      {mobileMenu && <button className="mobile-scrim" onClick={() => setMobileMenu(false)} aria-label="Close navigation"/>}

      <main className="main-content" id="overview">
        <header className="topbar">
          <div className="topbar-left">
            <button className="icon-btn mobile-menu" onClick={() => setMobileMenu(true)} aria-label="Open menu"><Menu size={20}/></button>
            <div className="breadcrumb">Workspace <span>/</span> <b>Overview</b></div>
          </div>
          <div className="topbar-actions">
            <div className="network-pill"><span className="network-dot"/> {CHAIN_NAME}</div>
            <button className="icon-btn notification" aria-label="Notifications"><Bell size={18}/></button>
            <button className={`connect-btn ${account ? "connected" : ""}`} onClick={account ? refreshData : connectWallet} disabled={busy}>
              <Wallet size={16}/>{busy ? "Connecting..." : account ? SHORT_ADDRESS(account) : "Connect wallet"}
              {account && <span className="connected-dot"/>}
            </button>
          </div>
        </header>

        <section className="welcome-row">
          <div>
            <div className="eyebrow"><span className="eyebrow-line"/> ETHERCORE ECOSYSTEM</div>
            <h1>Your assets.<br/><span>Your control.</span></h1>
            <p className="welcome-copy">A clear view of your CoreToken holdings and on-chain details.</p>
          </div>
          <div className="hero-orb" aria-hidden="true">
            <div className="orb-ring ring-one"/><div className="orb-ring ring-two"/>
            <div className="orb-core">E<span>✦</span></div>
            <div className="orb-label">DECENTRALIZED<br/>BY DESIGN</div>
          </div>
        </section>

        {error && <div className="alert"><CircleHelp size={17}/><span>{error}</span><button onClick={() => setError("")} aria-label="Dismiss"><X size={16}/></button></div>}

        <section className="stats-grid" id="token">
          <article className="stat-card balance-card">
            <div className="card-top"><span className="card-label">MY TOKEN BALANCE</span><span className="token-chip">CT <span>◆</span></span></div>
            <div className="balance-number">{formattedBalance} <span>{symbol}</span></div>
            <div className="card-bottom"><span className="muted">{account ? "Live wallet balance" : "Connect wallet to view balance"}</span><span className="round-icon"><Wallet size={17}/></span></div>
            <div className="balance-glow"/>
          </article>
          <article className="stat-card supply-card">
            <div className="card-top"><span className="card-label">TOTAL TOKEN SUPPLY</span><span className="mini-icon"><Activity size={17}/></span></div>
            <div className="supply-number">{formattedSupply}<span> CT</span></div>
            <div className="card-bottom"><span className="muted">Fixed initial supply · 18 decimals</span><span className="supply-tag"><LockKeyhole size={12}/> Fixed</span></div>
          </article>
        </section>

        <section className="content-grid">
          <article className="panel wallet-panel">
            <div className="panel-heading"><div><div className="eyebrow small">WALLET</div><h2>Wallet connection</h2></div><span className={`status-badge ${account ? "ok" : ""}`}><span/> {account ? "Connected" : "Not connected"}</span></div>
            {account ? (
              <div className="wallet-connected">
                <div className="wallet-avatar"><Wallet size={22}/></div>
                <div className="wallet-details"><strong>{SHORT_ADDRESS(account)}</strong><span>{networkMatches ? `${CHAIN_NAME} network` : "Network mismatch"}</span></div>
                <button className="text-action" onClick={() => navigator.clipboard.writeText(account)}><Copy size={14}/> Copy</button>
              </div>
            ) : (
              <div className="wallet-empty">
                <div className="wallet-empty-icon"><Wallet size={23}/></div>
                <div><strong>Connect your wallet</strong><p>Connect MetaMask or another injected wallet to read your CT balance.</p></div>
                <button className="outline-btn" onClick={connectWallet} disabled={busy}>Connect <ArrowUpRight size={15}/></button>
              </div>
            )}
            {account && !networkMatches && <div className="inline-warning">Switch your wallet to {CHAIN_NAME} (chain ID {TARGET_CHAIN_ID}) to read token data.</div>}
            <div className="panel-footer"><span><ShieldCheck size={14}/> Non-custodial connection</span><span>Read-only access</span></div>
          </article>

          <article className="panel token-panel">
            <div className="panel-heading"><div><div className="eyebrow small">ASSET DETAILS</div><h2>CoreToken overview</h2></div><div className="token-logo">CT</div></div>
            <div className="token-title"><div className="token-symbol">CT</div><div><strong>{tokenName}</strong><span>EtherCore utility token</span></div></div>
            <div className="detail-list">
              <div><span>Token symbol</span><strong>{symbol}</strong></div>
              <div><span>Decimals</span><strong>{decimals}</strong></div>
              <div><span>Maximum supply</span><strong>100,000,000 CT</strong></div>
              <div><span>Minting</span><strong className="no-value"><LockKeyhole size={13}/> Disabled</strong></div>
              <div><span>Burning</span><strong className="no-value"><LockKeyhole size={13}/> Disabled</strong></div>
            </div>
          </article>
        </section>

        <section className="panel contract-panel" id="contract">
          <div className="panel-heading"><div><div className="eyebrow small">ON-CHAIN TRANSPARENCY</div><h2>Contract information</h2></div><span className="verified-label"><ShieldCheck size={15}/> Contract details</span></div>
          <div className="contract-address-row">
            <div className="contract-symbol"><FileCode2 size={20}/></div>
            <div className="contract-address"><span>CoreToken contract address</span><strong>{configured ? SHORT_ADDRESS(CONTRACT_ADDRESS) : "Add contract address in environment settings"}</strong></div>
            {configured && <button className="copy-btn" onClick={copyAddress}>{copied ? <Check size={15}/> : <Copy size={15}/>} {copied ? "Copied" : "Copy"}</button>}
            {configured && <a className="explorer-btn" href={`${EXPLORER_URL}/address/${CONTRACT_ADDRESS}`} target="_blank" rel="noreferrer">Explorer <ExternalLink size={14}/></a>}
          </div>
          <div className="contract-meta">
            <div><span>Network</span><strong><Globe2 size={14}/> {CHAIN_NAME}</strong></div>
            <div><span>Chain ID</span><strong>{TARGET_CHAIN_ID}</strong></div>
            <div><span>Standard</span><strong>ERC-20</strong></div>
            <div><span>Admin privileges</span><strong className="no-value">None</strong></div>
          </div>
          {!configured && <div className="setup-note"><CircleHelp size={15}/> Live contract reads are waiting for the deployed contract address. No placeholder address is shown.</div>}
        </section>

        <footer className="footer">
          <div className="footer-brand"><div className="footer-mark">E</div><strong>ETHERCORE</strong></div>
          <span>Built for transparency. Powered by Ethereum.</span>
          <span className="footer-status"><span className="live-dot"/> {status === "loading" ? "Syncing" : status === "error" ? "Read error" : "Interface online"}</span>
        </footer>
      </main>
    </div>
  );
}

export default App;